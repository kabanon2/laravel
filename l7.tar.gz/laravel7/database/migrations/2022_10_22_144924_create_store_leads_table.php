<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStoreLeadsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('store_leads', function (Blueprint $table) {
            $table->uuid('id');
            $table->char('provider', 32);
            $table->char('source', 128);
            $table->json('data');
            $table->dateTime('created_at')->useCurrent();
            $table->boolean('processed')->default(0);
            $table->dateTime('processed_at')->nullable();

            $table->primary('id');
            $table->index(['processed', 'provider', 'source']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('store_leads');
    }
}
