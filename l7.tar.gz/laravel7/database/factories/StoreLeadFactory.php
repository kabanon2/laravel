<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\StoreLead;
use Faker\Generator as Faker;
use Illuminate\Support\Str;

$factory->define(StoreLead::class, function (Faker $faker) {

    $provider = $faker->randomElements(['MAIL', 'AT', 'CATS', 'LD2C'])[0];
    // Data case / provider.

    $processed = $faker->boolean;

    return [
        'id' => $faker->uuid,
        'provider' => $provider,
        'source' => Str::random(16),
        'data' => json_encode([]),
        'created_at' => $faker->dateTimeBetween('-3 week', '-1 day'),
        'processed' => $processed,
        'processed_at' => ($processed) ? now() : null,
    ];
});
