<?php

namespace App;

use App\Casts\Json;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class StoreLead extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'store_leads';
    /**
     * Indicates if the model's ID is auto-incrementing.
     *
     * @var bool
     */
    public $incrementing = false;
    /**
     * The data type of the auto-incrementing ID.
     *
     * @var string
     */
    protected $keyType = 'string';
    /**
     * Indicates if the model should be timestamped.
     *
     * @var bool
     */
    public $timestamps = false;
    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'data' => Json::class,
    ];

    /**
     * 
     */
    /*
     protected $attributes = [
        'id' => Str::uuid(),
    ];
    */
    
}
