
<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DimPole extends Model
{
    use HasFactory;
    protected $connection = 'olap';
    protected $table = 'dim_poles';
    protected $fillable = ['uuid', 'label'];
}
