
<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DimApplication extends Model
{
    use HasFactory;
    protected $connection = 'olap';
    protected $table = 'dim_applications';
    protected $fillable = ['uuid', 'label'];
}
