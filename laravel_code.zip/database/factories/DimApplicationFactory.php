
<?php
namespace Database\Factories;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class DimApplicationFactory extends Factory
{
    public function definition()
    {
        return [
            'uuid' => Str::uuid(),
            'label' => $this->faker->company(),
        ];
    }
}
