
<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use App\Models\DimApplication;

class DimApplicationSeeder extends Seeder
{
    public function run()
    {
        DimApplication::factory()->count(10)->create();
    }
}
